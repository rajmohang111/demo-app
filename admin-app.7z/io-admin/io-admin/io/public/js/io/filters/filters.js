/**
 * Created with JetBrains WebStorm.
 * User: Anoj
 * Date: 9/9/13
 * Time: 7:00 PM
 * Angular Filters
 */
define([
    'angular'
], function (angular) {
    var filterApp = angular.module('io.admin.filters', [ ]);

});

